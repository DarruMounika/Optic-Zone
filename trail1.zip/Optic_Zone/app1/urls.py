from django.urls import path
from .views import *

app_name = 'app1'
urlpatterns = [
    path('',home,name='home'),
    path('eyeglassess/',eyeglassess,name='eyeglassess'),
    path('termsandconditions/',termsandconditions,name='termsandconditions'),
    path('contact/', contact, name='contact')]

