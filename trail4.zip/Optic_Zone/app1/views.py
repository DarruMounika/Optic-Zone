from django.shortcuts import render,redirect
from .models import Product
# Create your views here.
def home(request):
    sunglasses = Product.objects.filter(category='Sunglasses')  # Fetch Sunglasses
    eyeglasses = Product.objects.filter(category='Eyeglasses')  # Fetch Eyeglasses
    return render(request, 'home.html', {'sunglasses': sunglasses, 'eyeglasses': eyeglasses})

def sunglass(request):
    products = Product.objects.filter(category='Sunglasses')
    return render(request,'sunglass.html',{'products': products})

def eyeglassess(request):
    products =  Product.objects.filter(category='Eyeglasses')
    return render(request,'eyeglassess.html', {'products': products})

def termsandconditions(request):
    return render(request,'termsandconditions.html')

def contact(request):
    return render(request,'contact.html')

def product_detail(request, id):
    product = Product.objects.get(id=id)
    return render(request, 'product_detail.html', {'product': product})

def view(request,id):
    products = Product.objects.get(id=id) 
    return render(request,'view_card.html',{'products': products})

def view_cart(request, id):
    product = Product.objects.get(id=id)  # Fetch product by ID
    return render(request, 'cart.html', {'product': product})

def delete(request,id):
    obj=Product.objects.get(id=id)
    obj.delete()
    return redirect('app1:view_cart')

def womenglasses(request):
    return render(request,'womenglasses.html')

def menglasses(request):
    return render(request,'menglasses.html')
