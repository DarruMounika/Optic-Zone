from django.shortcuts import render

# Create your views here.
def main(request):
    return render(request,'base.html')

def termsandconditions(request):
    return render(request,'termsandconditions.html')