from django.urls import path
from .views import *

app_name = 'app1'
urlpatterns = [
    path('',main,name='main'),
    path('termsandconditions/',termsandconditions,name='termsandconditions')]

