from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'home.html')

def eyeglassess(request):
    return render(request,'eyeglassess.html')

def termsandconditions(request):
    return render(request,'termsandconditions.html')

def contact(request):
    return render(request,'contact.html')