function toggleForm() {
    const loginContainer = document.getElementById('login-container');
    const signupContainer = document.getElementById('signup-container');
    loginContainer.classList.toggle('hidden');
    signupContainer.classList.toggle('hidden');
}
