from django.shortcuts import render,redirect,get_object_or_404,HttpResponse
from .models import Product,Cart,Glasses,WGlasses
# Create your views here.
from .forms import registerform
from django.contrib.auth import authenticate,login
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from .forms import loginform
# Create your views here.
def regview(request):
    f1=registerform()
    if request.method=='POST':
        f1=registerform(request.POST)
        if f1.is_valid():
            print(f1)
            f1.save()
            return HttpResponse('form is submitted')
    return render(request,'reg.html',{'form':f1})

@login_required
def home(request):
    return render(request,'home.html')

def loginview(request):
    l1=loginform()
    if request.method=='POST':
        f1=loginform(request.POST)
        if f1.is_valid():
            username=f1.cleaned_data.get('username')
            password=f1.cleaned_data.get('password')
            user=authenticate(request,username=username,password=password)
            if user:
                login(request,user)
                return render(request,'home.html')
            else:
                return HttpResponse('invalid user')
    return render(request,'login.html',{'form':l1})


def home(request):
    sunglasses = Product.objects.filter(category='Sunglasses')  # Fetch Sunglasses
    eyeglasses = Product.objects.filter(category='Eyeglasses')  # Fetch Eyeglasses
    return render(request, 'home.html', {'sunglasses': sunglasses, 'eyeglasses': eyeglasses})

def sunglass(request):
    products = Product.objects.filter(category='Sunglasses')
    return render(request,'sunglass.html',{'products': products})

def eyeglassess(request):
    products =  Product.objects.filter(category='Eyeglasses')
    return render(request,'eyeglassess.html', {'products': products})

def termsandconditions(request):
    return render(request,'termsandconditions.html')

def contact(request):
    return render(request,'contact.html')

def product_detail(request, id):
    product = None  # Initialize product as None

    # Try to get the product from the Product table first
    try:
        product = Product.objects.get(id=id)
    except Product.DoesNotExist:
        # If not found, try to get from Glasses table
        product = get_object_or_404(Glasses, id=id)

    return render(request, 'product_detail.html', {'product': product})

def view(request,id):
    products = Product.objects.get(id=id) 
    return render(request,'view_card.html',{'products': products})

def view_cart(request, id):
    cart_items = Cart.objects.filter(user_id=id) 
    print(cart_items) # Fetch all cart items for the user
    return render(request, 'cart.html', {'cart_items': cart_items})


def delete(request, id):
    cart_item = get_object_or_404(Cart, id=id)
    cart_item.delete()  # Remove only from the cart

    return redirect('app1:view_cart', id=cart_item.user_id)  # Redirect to home if no products remain


def womenglasses(request):
    glasses = WGlasses.objects.all()
    return render(request,'womenglasses.html',{'glasses': glasses})

def menglasses_list(request):
    glasses = Glasses.objects.all()
    return render(request,'menglasses.html',{'glasses': glasses})


def add_to_cart(request, id):
    # First, try to get the product from the Product table
    product = get_object_or_404(Product, id=id)
    
    # If the product is not found, check the Glasses table (if needed)
    if not product:
        product = get_object_or_404(Glasses, id=id)
    
    # Get the current user's id. Use session or a default if not authenticated
    user_id = request.user.id if request.user.is_authenticated else 1  # Or use session user ID if needed
    
    # Check if the product is already in the cart for the user
    cart_item, created = Cart.objects.get_or_create(product=product, user_id=user_id)

    if created:
        print(f"✅ {product.name} added to cart for user {user_id}")
    else:
        print(f"⚠️ {product.name} is already in the cart for user {user_id}")

    # Redirect to the cart page or wherever you want to show the cart
    return redirect('app1:view_cart', id=user_id)